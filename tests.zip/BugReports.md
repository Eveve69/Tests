# Bug Reports – Personal Website

### 🐛 Bug #1 – Image Hover Effect Overflows
- **Location:** Portfolio section
- **Steps to Reproduce:**
  1. Go to the Portfolio section
  2. Hover over the third image
- **Expected:** Image zooms smoothly inside container
- **Actual:** Image overflows and breaks layout slightly
- **Severity:** Minor

### 🐛 Bug #2 – Scrollbar Not Styled on Firefox
- **Location:** All pages
- **Browser:** Firefox v110+
- **Expected:** Custom scrollbar style (as in Chrome)
- **Actual:** Default browser scrollbar shown
- **Severity:** Cosmetic
