# Personal Website – Jem Ivy M. Bacaron

This is a personal portfolio website built using HTML, CSS, and JavaScript. It showcases my education, background, certifications, and sample artworks.

## 🔧 Technologies Used
- HTML5
- CSS3
- JavaScript
- FontAwesome

## 🎯 Purpose
Originally created as a web portfolio, this project has been updated to demonstrate manual software testing skills. It includes:
- Sample bug reports
- Test cases
- Responsive UI tests

## 📂 QA Materials
- `BugReports.md`: Documented issues with reproduction steps and severity levels
- `TestCases.md`: Structured manual test cases
