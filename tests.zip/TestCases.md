# Manual Test Cases – Personal Website

| Test ID | Feature        | Step                          | Expected Result                       | Status |
|---------|----------------|-------------------------------|----------------------------------------|--------|
| TC01    | Navigation      | Click "About" in menu         | Scrolls to #about section              | Pass   |
| TC02    | Contact Form    | Submit with valid inputs      | Email gets sent                        | Pass   |
| TC03    | Button Hover    | Hover over any `.btn`         | Background color changes to cyan       | Pass   |
| TC04    | Responsive View | View on mobile screen width   | Layout adjusts properly (no overflow) | Pass   |
| TC05    | Portfolio Img   | Hover over image              | Slight zoom without breaking layout    | Fail   |
